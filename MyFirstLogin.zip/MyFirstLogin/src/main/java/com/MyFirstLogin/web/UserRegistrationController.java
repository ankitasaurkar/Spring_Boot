package com.MyFirstLogin.web;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.persistence.criteria.Path;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.MyFirstLogin.model.User;
import com.MyFirstLogin.service.UserService;
import com.MyFirstLogin.web.dto.UserRegistrationDto;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController 
{
	private UserService userService;

	public UserRegistrationController(UserService userService) {
		super();
		this.userService = userService;
	}
	
	@ModelAttribute("user")
	public UserRegistrationDto userRegistrationDto()
	{
		return new UserRegistrationDto();
	}
	
	@GetMapping
	public String showRegistrationForm(Model model)
	{
		model.addAttribute("user",new UserRegistrationDto());
		return "registration";
	}
	
	@PostMapping
	public String registerUserAccount(@ModelAttribute("user") UserRegistrationDto registrationDto,@RequestParam("logo") MultipartFile multipartFile) throws IOException
	{
		String fileName=StringUtils.cleanPath(multipartFile.getOriginalFilename());
		registrationDto.setLogo(fileName);
		User savedBrand=userService.save(registrationDto);
		String uploadDir="/myImages/"+ savedBrand.getId();
		java.nio.file.Path uploadPath=Paths.get(uploadDir);
		if(!Files.exists(uploadPath))
		{
			Files.createDirectories(uploadPath);
		}
		
		try
		(InputStream inputStream=multipartFile.getInputStream())
		{
		java.nio.file.Path filePath=uploadPath.resolve(fileName);
		Files.copy(inputStream,filePath,StandardCopyOption.REPLACE_EXISTING);
		}
		catch(IOException e)
		{
			throw new  IOException("Could Not Save Uploaded File"+fileName);
		}
		
		
		
		
		
		return "redirect:/registration?success";
		
	}
	
}
