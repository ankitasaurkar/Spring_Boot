package com.MyFirstLogin.service;

import com.MyFirstLogin.model.User;
import com.MyFirstLogin.web.dto.UserRegistrationDto;

public interface UserService 
{
	User save(UserRegistrationDto registrationDto);

}
