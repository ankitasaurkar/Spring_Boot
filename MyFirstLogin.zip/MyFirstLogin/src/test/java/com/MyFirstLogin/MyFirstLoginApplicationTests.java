package com.MyFirstLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
